Requirements----------------

1. Python3
2. Flask
3. Heroku
4. Gunicorn

To run type in terminal-----

FLASK_APP=app.py flask run --port=5000

Note-------------------------

1. Do Not Change the folder Structure.
2. Change the port no. if mentioned port is busy.
3. Ctrl+C every time to close the process and use the same port (if not used by others).