from flask import Flask, jsonify, render_template, request, redirect, url_for, send_from_directory
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = os.path.dirname(os.path.abspath(__file__)) + '/downloads/'
DOWNLOAD_FOLDER = os.path.dirname(os.path.abspath(__file__))
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app = Flask(__name__, static_url_path="/static")
DIR_PATH = os.path.dirname(os.path.realpath(__file__))
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_FOLDER
# limit upload size upto 8mb
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def deflt():
   images = os.listdir(os.path.join(app.static_folder, "images"))
   return render_template('index.html', images=images)

def get_coordinates_text(in_txt):
   saddr='21.5,78.9'
   daddr='31.5,79.9//@31.5,79.9'
   return(saddr,daddr)

def get_coordinates_image(in_img):
   saddr='45.5,78.9'
   daddr='55.5,79.9//@55.5,79.9'
   return(saddr,daddr)

@app.route('/text-coordinate',methods = ['POST'])
def resulttext():
    if request.method == 'POST':
        in_txt = request.form['inTxt']
        saddr, daddr = get_coordinates_text(in_txt)
        images = os.listdir(os.path.join(app.static_folder, "images"))
        return render_template('index.html', saddr=saddr, daddr=daddr, images=images)

@app.route('/image-coordinate',methods = ['POST'])
def resultimage():
    if request.method == 'POST':
        in_img = request.form['inImg']
        saddr, daddr = get_coordinates_image(in_img)
        images = os.listdir(os.path.join(app.static_folder, "images"))
        return render_template('index.html', saddr=saddr, daddr=daddr, images=images)
    
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename, as_attachment=True)

if __name__ == '__main__':
   app.run(host="0.0.0.0", port=6060)
